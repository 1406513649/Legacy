/*********************************************************************
 *   Copyright 2010, UCAR/Unidata
 *   See netcdf/COPYRIGHT file for copying and redistribution conditions.
 *   $Id$
 *   $Header$
 *********************************************************************/

#ifndef NCRPC_H
#define NCRPC_H 1

/**************************************************/
/*Forwards*/
struct NC;
struct NC_URI;
struct NClist;


#endif /*NCRPC_H*/

